#!/bin/bash
PID_FILE="/tmp/lobster-guardian.pid"
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    kill $PID && echo "Stopped Service (PID: $PID)"
    rm -f "$PID_FILE"
else
    echo "服务未在运行 (未找到 PID 文件)。"
fi
