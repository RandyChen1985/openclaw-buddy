# 🦞 Lobster Guardian (小龙虾守护者)

本项目是专门为 **OpenClaw (小龙虾)** 设计的独立守护程序。它作为“带外管理”工具运行，旨在解决 OpenClaw 因配置改错导致网关宕机、进而导致管理界面失联的问题。

## 🛠️ 工作原理
1. **周期性健康检查**：每隔 30 秒通过 TCP 端口和 CLI 命令探测 OpenClaw 运行状态。
2. **故障诊断**：一旦发现服务宕机，自动对比当前的 `openclaw.json` 与备份配置的差异并生成 Markdown 报表。
3. **多级自愈**：检测到配置错误导致的启动失败后，自动将 `openclaw.json.bak` 还原；若回滚失败或缺失备份，则执行 `openclaw doctor --fix` 自动修复环境。
4. **强制自愈**：执行 `openclaw gateway --force` 强行恢复服务。
5. **主动告警**：支持通过飞书 Webhook 发送故障与自愈成功的实时告警。

## 📊 运行实例
以下是 `logs/guardian.log` 中记录的一次真实自愈过程：
```text
2026/03/10 12:25:23 🛡️ Guardian started (PID: 30362). Watching OpenClaw...
2026/03/10 12:25:23 🛡️ Guardian monitor loop started. Every 30 seconds.
2026/03/10 12:25:58 ✅ OpenClaw is healthy.
2026/03/10 12:27:53 ⚠️ Port 18789 is not listening! Service might be down.
2026/03/10 12:27:53 🛠️ Initiating self-healing process for reason: Port Down
2026/03/10 12:27:53 🔄 Attempting to recover service...
2026/03/10 12:27:53 ✅ Config rollback successful.
2026/03/10 12:27:53 🚀 Requesting gateway force start...
2026/03/10 12:27:53 ✨ Gateway start request sent. Self-healing cycle completed.
2026/03/10 12:28:27 ✅ OpenClaw is healthy.
```

## 🚀 快速开始
### 前提条件
- 启动本程序前，请确保 **OpenClaw 已经正常运行**。
- 本程序采用单例模式运行，PID 锁文件位于 `/tmp/lobster-guardian.pid`。

### 运行与停止
```bash
./start.sh   # 启动守护进程
./stop.sh    # 停止守护进程
```

## 📂 目录说明
- **lib/**: 存放核心二进制程序。
- **logs/**: 存放 Guardian 自身的运行日志。
- **reports/**: 存放服务崩溃后的差异分析报表。
- **env**: 配置文件，可调整巡检频率和路径。
