#!/bin/bash
cd "$(dirname "$0")"
PID_FILE="/tmp/openclaw-buddy-linux.pid"

if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if ps -p $PID > /dev/null; then
        echo "❌ 服务已经在运行 (PID: $PID)"
        exit 1
    fi
    rm -f "$PID_FILE"
fi

echo "🚀 正在启动服务..."
chmod +x ./lib/openclaw-buddy
(trap "" INT; nohup ./lib/openclaw-buddy >> ./logs/guardian.log 2>&1 &)
echo $! > "$PID_FILE"
echo "✅ 启动成功，PID: $(cat $PID_FILE)"
echo "📋 正在自动追踪启动日志 (按 Ctrl+C 停止追踪，服务将继续后台运行)..."
sleep 1
# tail 运行在前台，接收到 Ctrl+C 后会退出，由于上面的 nohup 在子 shell 中由 trap 保护，不会受影响
tail -n 20 -f ./logs/guardian.log
