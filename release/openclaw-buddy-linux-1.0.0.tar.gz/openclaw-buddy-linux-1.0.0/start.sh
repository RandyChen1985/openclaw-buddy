#!/bin/bash
cd "$(dirname "$0")"
PID_FILE="/tmp/openclaw-buddy-linux.pid"

if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if ps -p $PID > /dev/null; then
        echo "❌ 服务已经在运行 (PID: $PID)"
        exit 1
    fi
    rm -f "$PID_FILE"
fi

echo "🚀 正在启动服务..."
chmod +x ./lib/openclaw-buddy
nohup ./lib/openclaw-buddy >> ./logs/guardian.log 2>&1 &
echo $! > "$PID_FILE"
echo "✅ 启动成功，PID: $(cat $PID_FILE)"
echo "💡 提示: 可通过 tail -f ./logs/guardian.log 查看实时日志"
