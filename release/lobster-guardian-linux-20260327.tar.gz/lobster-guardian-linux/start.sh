#!/bin/bash
cd "$(dirname "$0")"
PID_FILE="/tmp/lobster-guardian-linux.pid"

if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if ps -p $PID > /dev/null; then
        echo "❌ 服务已经在运行 (PID: $PID)"
        exit 1
    fi
    rm -f "$PID_FILE"
fi

echo "🚀 正在启动服务..."
chmod +x ./lib/lobster-monitor
nohup ./lib/lobster-monitor >> ./logs/guardian.log 2>&1 &
echo $! > "$PID_FILE"
echo "✅ 启动成功，PID: $(cat $PID_FILE)"
