#!/bin/bash
PID_FILE="/tmp/lobster-guardian-linux.pid"
if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    kill $PID && echo "✅ 服务已停止 (PID: $PID)"
    rm -f "$PID_FILE"
else
    echo "⚠️ 未发现正在运行的服务"
fi
