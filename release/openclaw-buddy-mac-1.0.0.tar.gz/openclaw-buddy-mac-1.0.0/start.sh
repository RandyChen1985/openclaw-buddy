#!/bin/bash
cd "$(dirname "$0")"
PID_FILE="/tmp/openclaw-buddy-mac.pid"
[ -f "$PID_FILE" ] && ps -p $(cat "$PID_FILE") > /dev/null && echo "❌ 已经在运行中" && exit 1
nohup ./lib/openclaw-buddy >> ./logs/guardian.log 2>&1 &
echo $! > "$PID_FILE"
echo "✅ macOS 版启动成功，PID: $(cat $PID_FILE)"
echo "💡 提示: 可通过 tail -f ./logs/guardian.log 查看实时日志"
