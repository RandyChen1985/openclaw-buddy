#!/bin/bash
PID_FILE="/tmp/lobster-guardian-mac.pid"
if [ -f "$PID_FILE" ]; then
    kill $(cat "$PID_FILE") && echo "✅ 已停止 (Mac)"
    rm -f "$PID_FILE"
else
    echo "⚠️ 未发现运行中的服务"
fi
