#!/bin/bash
cd "$(dirname "$0")"
PID_FILE="/tmp/lobster-guardian-mac.pid"
[ -f "$PID_FILE" ] && ps -p $(cat "$PID_FILE") > /dev/null && echo "❌ 已经在运行中" && exit 1
nohup ./lib/lobster-monitor >> ./logs/guardian.log 2>&1 &
echo $! > "$PID_FILE"
echo "✅ macOS 版启动成功，PID: $(cat $PID_FILE)"
